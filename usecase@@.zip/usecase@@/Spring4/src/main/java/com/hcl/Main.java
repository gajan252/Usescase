package com.hcl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");

		Employee emp = (Employee) context.getBean("employee");

		System.out.println(emp.getId() + " " + emp.getName() + " " + emp.getAddress().getCity() + " "
				+ emp.getAddress().getZipCode());
		System.out.println(emp);
		System.out.println(emp.getAddress());

		System.out.println();

		Address adr = (Address) context.getBean("address");
		adr.setCity("Delhi");
		adr.setZipCode(677666);
		System.out.println(adr.getCity() + " " + adr.getZipCode());
		System.out.println(adr);

		((AbstractApplicationContext) context).close();
	}

}
