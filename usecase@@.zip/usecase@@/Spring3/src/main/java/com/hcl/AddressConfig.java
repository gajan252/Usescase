package com.hcl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

@Configuration
public class AddressConfig {

	@Bean
	@Lazy
	@Scope(value = "prototype")
	public Address getAddress() {
		return new Address();
	}

}
