package com.hcl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(AddressConfig.class)
public class EmployeeConfig {

	@Bean
	public Employee getEmployee() {
		return new Employee();
	}

}
