package com.hcl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class Main {

	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(EmployeeConfig.class);

		Employee emp = context.getBean(Employee.class);
		Address adr = context.getBean(Address.class);
		adr.setCity("Delhi");
		adr.setZipCode(677666);

		emp.setId(1);
		emp.setName("Ram");
		emp.setAddress(adr);

		Address adr1 = context.getBean(Address.class);
		adr1.setCity("Bengaluru");
		adr1.setZipCode(560087);

		System.out.println(emp.getId() + " " + emp.getName() + " " + emp.getAddress().getCity() + " "
				+ emp.getAddress().getZipCode());
		System.out.println(emp.getAddress());
		System.out.println();
		System.out.println(adr1.getCity() + " " + adr1.getZipCode());
		System.out.println(adr1);
		
		((AbstractApplicationContext) context).close();

	}

}
