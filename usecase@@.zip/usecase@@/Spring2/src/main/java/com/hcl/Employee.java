package com.hcl;

import org.springframework.stereotype.Component;

@Component
public class Employee {

	private Integer id;
	private String name;
//	@Autowired
//	@Qualifier("address1")
	private Address address;

	public Employee() {
	}

	public Employee(Integer id, String name, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}

	public Integer getId() {
		return id;
	}

//	@Required
	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}

}
