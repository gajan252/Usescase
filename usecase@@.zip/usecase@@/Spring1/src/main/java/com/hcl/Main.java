package com.hcl;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		context.registerShutdownHook();

		Employee emp = (Employee) context.getBean("employee");
		Address adr = (Address) context.getBean("address");
		
		System.out.println(emp.getId() + " " + emp.getName() + " " + emp.getAddress().getCity() + " "
				+ emp.getAddress().getZipCode());
		System.out.println(emp);
		System.out.println(emp.getAddress());

		System.out.println();

		System.out.println(adr.getCity() + " " + adr.getZipCode());
		System.out.println(adr);
		
		Employee emp1 = (Employee) context.getBean("employee1");
		
		System.out.println();
		System.out.println(emp1);

		context.close();

	}

}
